"use strict";

/* Demonstração: em produção, autenticação e permissões devem ser validadas no servidor. */
const SENHA_ADMIN = "admin123";

/* =====================================================
   1. SEQUÊNCIA E TEMPOS ESTIMADOS
   min = minutos estimados desde a leitura da etapa anterior.
   Chegada (min null) usa a duração do voo de cada bagagem.
   ===================================================== */
const ETAPAS = [
  { nome: "Despacho", sigla: "DSP", min: 0,
    pontos: ["Balcão 07 · Terminal 1", "Balcão 12 · Terminal 1", "Balcão 21 · Terminal 2"] },
  { nome: "Triagem", sigla: "TRI", min: 10,
    pontos: ["Central de triagem · Esteira A", "Central de triagem · Esteira B", "Central de triagem · Esteira C"] },
  { nome: "Segurança", sigla: "SEG", min: 15,
    pontos: ["Raio-X 2 · Área restrita", "Raio-X 4 · Área restrita"] },
  { nome: "Carregamento", sigla: "CAR", min: 20,
    pontos: ["Pátio · Posição 14", "Pátio · Posição 22", "Pátio · Posição 31"] },
  { nome: "Aeronave", sigla: "AER", min: 15,
    pontos: ["Aeronave · Porão dianteiro", "Aeronave · Porão traseiro"] },
  { nome: "Chegada", sigla: "CHE", min: null,
    pontos: ["Pátio de desembarque · Posição 05", "Pátio de desembarque · Posição 09"] },
  { nome: "Esteira", sigla: "EST", min: 20,
    pontos: ["Esteira 3 · Salão de restituição", "Esteira 5 · Salão de restituição"] },
];

/* Local (fictício) e leitor RFID de cada leitura. Determinístico: mesma bagagem e etapa => mesmo ponto. */
function pontoDaLeitura(bag, idx) {
  const n = parseInt(bag.id.replace(/\D/g, ""), 10);
  const k = (n + idx) % ETAPAS[idx].pontos.length;
  return { local: ETAPAS[idx].pontos[k], leitor: `RFID-${ETAPAS[idx].sigla}-${String(k + 1).padStart(2, "0")}` };
}

/* Relógio do sistema (o administrador pode avançá-lo para testar atrasos) */
let deslocamentoMs = 0;
const agora = () => new Date(Date.now() + deslocamentoMs);

const tempoEsperado = (bag, idx) => ETAPAS[idx].min ?? bag.duracaoVoo;

/* Prazo da próxima etapa = última leitura + tempo estimado. Sempre o mesmo resultado para as mesmas entradas. */
function prazoProxima(bag) {
  if (bag.proximo >= ETAPAS.length || !bag.ultimaLeitura) return null;
  return new Date(bag.ultimaLeitura.getTime() + tempoEsperado(bag, bag.proximo) * 60000);
}

function atrasoMin(bag, t) {
  const p = prazoProxima(bag);
  return p && t > p ? Math.ceil((t - p) / 60000) : 0;
}

/* =====================================================
   2. VALIDAÇÃO DETERMINÍSTICA DA SEQUÊNCIA (sem IA)
   ===================================================== */
function validarLeitura(bag, idxLido) {
  const lida = ETAPAS[idxLido].nome;

  if (bag.proximo >= ETAPAS.length) {
    return { ok: false, tipo: "Leitura após a entrega",
      msg: `Leitura em "${lida}" depois de a bagagem já ter chegado à esteira.` };
  }

  const esperada = ETAPAS[bag.proximo].nome;

  if (idxLido === bag.proximo) {
    return { ok: true, tipo: "Leitura válida", msg: `Etapa "${lida}" confirmada.` };
  }
  if (idxLido > bag.proximo) {
    const puladas = ETAPAS.slice(bag.proximo, idxLido).map(e => e.nome).join(", ");
    return { ok: false, tipo: "Etapa pulada",
      msg: `Leitura em "${lida}", mas o esperado era "${esperada}". Etapa(s) não registrada(s): ${puladas}.` };
  }
  if (idxLido === bag.proximo - 1) {
    return { ok: false, tipo: "Leitura repetida",
      msg: `Nova leitura em "${lida}", etapa já registrada. O esperado era "${esperada}".` };
  }
  return { ok: false, tipo: "Etapa anterior",
    msg: `Leitura em "${lida}", etapa anterior à atual. O esperado era "${esperada}".` };
}

function registrarLeitura(bag, idxLido, quando) {
  const r = validarLeitura(bag, idxLido);
  const atraso = r.ok ? atrasoMin(bag, quando) : 0; // leitura correta, mas depois do prazo
  const ponto = pontoDaLeitura(bag, idxLido);

  bag.historico.push({
    quando,
    etapa: ETAPAS[idxLido].nome,
    local: ponto.local,
    leitor: ponto.leitor,
    tipo: r.ok ? "ok" : "alerta",
    atraso: atraso > 0,
    titulo: atraso ? "Leitura válida com atraso" : r.tipo,
    msg: r.msg + (atraso ? ` Prazo excedido em ${atraso} min.` : ""),
  });

  bag.etapaAtual = idxLido;
  bag.proximo = idxLido + 1;
  bag.ultimaLeitura = quando;
  bag.localAtual = ponto.local;
  if (!r.ok) bag.alerta = { tipo: r.tipo, msg: r.msg };
  return { ...r, local: ponto.local };
}

/* Registra no histórico (uma vez por etapa) que o prazo foi perdido */
function registrarAtrasos(t) {
  bagagens.forEach(b => {
    if (b.arquivada || !atrasoMin(b, t)) return;
    const chave = `${b.proximo}|${b.ultimaLeitura.getTime()}`;
    if (b.atrasoRegistrado === chave) return;
    b.atrasoRegistrado = chave;
    b.historico.push({ quando: t, tipo: "alerta", atraso: true, titulo: "Atraso",
      msg: `Etapa "${ETAPAS[b.proximo].nome}" esperada até ${hm(prazoProxima(b))} e ainda não lida.` });
  });
}

function statusDe(bag, t) {
  if (bag.arquivada) return { chave: "arquivada", texto: "Arquivada" };
  if (bag.alerta) return { chave: "alerta", texto: "Alerta" };
  if (bag.proximo >= ETAPAS.length) return { chave: "concluida", texto: "Concluída" };
  if (atrasoMin(bag, t)) return { chave: "atrasada", texto: "Atrasada" };
  return { chave: "normal", texto: "Normal" };
}

/* =====================================================
   3. DADOS FICTÍCIOS (10 bagagens)
   ultimoHa = minutos desde a última leitura; duracaoVoo em minutos.
   ===================================================== */
const SEED = [
  { id: "BG-1001", reserva: "AZ4K9P", voo: "AV 301", destino: "Lisboa",       duracaoVoo: 600, leituras: [0, 1, 2, 3],             ultimoHa: 5 },
  { id: "BG-1002", reserva: "B7X2MQ", voo: "AV 214", destino: "Buenos Aires", duracaoVoo: 180, leituras: [0, 1],                   ultimoHa: 22 },
  { id: "BG-1003", reserva: "C3T8WN", voo: "AV 120", destino: "Salvador",     duracaoVoo: 120, leituras: [0, 1, 2, 3, 4, 5, 6],    ultimoHa: 30 },
  { id: "BG-1004", reserva: "D9R5LV", voo: "AV 450", destino: "Miami",        duracaoVoo: 540, leituras: [0, 1, 3],                ultimoHa: 8 },
  { id: "BG-1005", reserva: "E2H6ZJ", voo: "AV 88",  destino: "Brasília",     duracaoVoo: 90,  leituras: [0],                      ultimoHa: 3 },
  { id: "BG-1006", reserva: "F8Y3GU", voo: "AV 302", destino: "Paris",        duracaoVoo: 660, leituras: [0, 1, 2, 3, 4],          ultimoHa: 40 },
  { id: "BG-1007", reserva: "G5N7CB", voo: "AV 215", destino: "Santiago",     duracaoVoo: 240, leituras: [0, 1, 2, 1],             ultimoHa: 12 },
  { id: "BG-1008", reserva: "H4M2SD", voo: "AV 77",  destino: "Recife",       duracaoVoo: 150, leituras: [0, 1, 2],                ultimoHa: 4 },
  { id: "BG-1009", reserva: "J6P9XE", voo: "AV 510", destino: "Londres",      duracaoVoo: 600, leituras: [0, 1, 2, 3, 4, 5],       ultimoHa: 25 },
  { id: "BG-1010", reserva: "K3W8RA", voo: "AV 91",  destino: "Curitiba",     duracaoVoo: 60,  leituras: [0, 2],                   ultimoHa: 26 },
];

function criarBagagens() {
  const base = agora().getTime();
  return SEED.map(s => {
    const bag = { id: s.id, reserva: s.reserva, voo: s.voo, destino: s.destino, duracaoVoo: s.duracaoVoo,
      etapaAtual: 0, proximo: 0, alerta: null, ultimaLeitura: null, atrasoRegistrado: null, arquivada: null, historico: [] };
    const n = s.leituras.length;
    s.leituras.forEach((idx, j) => {
      registrarLeitura(bag, idx, new Date(base - (s.ultimoHa + (n - 1 - j) * 9) * 60000));
    });
    return bag;
  });
}

let bagagens = criarBagagens();

/* =====================================================
   4. SIMULAÇÃO RFID (somente administrador)
   O sorteio só gera a leitura de teste; o alerta vem sempre de validarLeitura().
   ===================================================== */
function simularLeitura(forcarErro) {
  if (papel !== "admin") return;
  const abertas = bagagens.filter(b => b.proximo < ETAPAS.length && !b.arquivada);
  if (!abertas.length) { mostrarAviso("Todas as bagagens já chegaram à esteira.", "erro"); return; }
  const bag = abertas[Math.floor(Math.random() * abertas.length)];

  let idx = bag.proximo;
  if (forcarErro || Math.random() < 0.25) {
    const outras = ETAPAS.map((_, i) => i).filter(i => i !== bag.proximo);
    idx = outras[Math.floor(Math.random() * outras.length)];
  }

  const t = agora();
  const r = registrarLeitura(bag, idx, t);
  const resumo = `${bag.id} · ${r.local} · ${formatarHora(t)}`;
  mostrarAviso(r.ok ? `Leitura registrada: ${resumo}` : `ALERTA: ${resumo}. ${r.msg}`, r.ok ? "ok" : "erro");
  atualizar();
}

/* =====================================================
   5. INTERFACE
   ===================================================== */
const $ = id => document.getElementById(id);
const modal = $("modal");
const login = $("login");
let bagAberta = null;
let papel = null; // "usuario" | "admin"
let visao = "ativas"; // "ativas" | "arquivadas"
let filtroAlertas = "todos"; // "todos" | "rota" | "atraso"
let minhasMalas = []; // IDs vinculados pelo usuário comum (somente nesta sessão)
try {
  const salvas = JSON.parse(sessionStorage.getItem("malas") || "[]");
  if (Array.isArray(salvas)) minhasMalas = salvas.filter(x => typeof x === "string");
} catch (e) {}
function salvarMalas() { try { sessionStorage.setItem("malas", JSON.stringify(minhasMalas)); } catch (e) {} }

const formatarHora = d => d.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
const hm = d => d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

function mostrarAviso(texto, classe) {
  const el = $("aviso");
  el.textContent = texto;
  el.className = "aviso " + (classe || "");
}

function textoPrevisto(b, t) {
  if (b.arquivada) return "—";
  const p = prazoProxima(b);
  if (!p) return "—";
  const m = atrasoMin(b, t);
  return m ? `<span class="atraso-txt">${hm(p)} · atrasada ${m} min</span>`
           : `${hm(p)} · em ${Math.ceil((p - t) / 60000)} min`;
}

function renderizar() {
  const t = agora();
  $("relogio").textContent = "Horário do sistema: " + formatarHora(t);

  /* Admin vê tudo; usuário comum só as malas vinculadas; sem login, nada */
  const escopo = papel === "admin" ? bagagens
    : papel === "usuario" ? bagagens.filter(b => minhasMalas.includes(b.id)) : [];
  const ativas = escopo.filter(b => !b.arquivada);
  const arquivadas = escopo.filter(b => b.arquivada);
  const comAlerta = ativas.filter(b => b.alerta);
  const atrasadas = ativas.filter(b => atrasoMin(b, t) > 0);
  const normais = ativas.filter(b => !b.alerta && !atrasoMin(b, t));
  $("card-total").textContent = ativas.length;
  $("n-ativas").textContent = `(${ativas.length})`;
  $("n-arquivadas").textContent = `(${arquivadas.length})`;
  $("aba-ativas").setAttribute("aria-pressed", visao === "ativas");
  $("aba-arquivadas").setAttribute("aria-pressed", visao === "arquivadas");
  $("card-normais").textContent = normais.length;
  $("card-alertas").textContent = comAlerta.length;
  $("card-atrasadas").textContent = atrasadas.length;

  const termo = $("busca").value.trim().toLowerCase();
  const visiveis = (papel === "usuario" ? escopo : visao === "ativas" ? ativas : arquivadas).filter(b => !termo || `${b.id} ${b.voo} ${b.destino}`.toLowerCase().includes(termo));
  $("tabela").innerHTML = visiveis.length ? visiveis.map(b => {
    const s = statusDe(b, t);
    const acao = papel === "admin" ? (b.arquivada ? ["restaurar", "Restaurar"] : ["arquivar", "Arquivar"]) : ["desvincular", "Remover"];
    return `<tr data-id="${b.id}" tabindex="0">
      <td data-label="ID">${b.id}</td><td data-label="Voo">${b.voo}</td><td data-label="Destino">${b.destino}</td>
      <td data-label="Localização atual">${b.localAtual}</td>
      <td data-label="Próxima etapa">${!b.arquivada && b.proximo < ETAPAS.length ? ETAPAS[b.proximo].nome : "—"}</td>
      <td data-label="Previsto">${textoPrevisto(b, t)}</td>
      <td data-label="Status"><span class="status ${s.chave}">${s.texto}</span></td>
      <td class="cel-acao" data-label="Ações"><button class="btn btn-pequeno" data-acao="${acao[0]}" data-id="${b.id}">${acao[1]}</button></td></tr>`;
  }).join("") : `<tr><td colspan="8">${papel === "usuario" ? "Nenhuma mala vinculada ainda. Informe o ID e o código da reserva acima." : "Nenhuma bagagem encontrada."}</td></tr>`;

  const liRota = b => `<li data-id="${b.id}" tabindex="0"><strong>${b.id}</strong> · ${b.alerta.tipo}<br>${b.alerta.msg}<br><span class="sub">Última leitura: ${b.localAtual}</span></li>`;
  const liAtraso = b => `<li class="atraso" data-id="${b.id}" tabindex="0"><strong>${b.id}</strong> · Atraso de ${atrasoMin(b, t)} min<br>Etapa "${ETAPAS[b.proximo].nome}" prevista até ${hm(prazoProxima(b))}.<br><span class="sub">Última leitura: ${b.localAtual}</span></li>`;
  const grupos = { rota: comAlerta.map(liRota), atraso: atrasadas.map(liAtraso) };
  grupos.todos = [...grupos.rota, ...grupos.atraso];
  const rotulos = { todos: "Todos", rota: "Rota", atraso: "Atraso" };
  document.querySelectorAll("#filtro-alertas [data-filtro]").forEach(btn => {
    const f = btn.dataset.filtro;
    btn.setAttribute("aria-pressed", f === filtroAlertas);
    btn.textContent = `${rotulos[f]} (${grupos[f].length})`;
  });
  const itens = grupos[filtroAlertas];
  $("lista-alertas").innerHTML = itens.length ? itens.join("")
    : `<li class="vazio">${filtroAlertas === "todos" ? "Nenhum alerta ativo." : "Nenhum alerta neste filtro."}</li>`;
}

function abrirModal(id) {
  const bag = bagagens.find(b => b.id === id);
  if (!bag || (papel === "usuario" && !minhasMalas.includes(id))) return;
  bagAberta = id;
  const t = agora();

  $("modal-titulo").textContent = bag.id;
  $("modal-sub").textContent = `Voo ${bag.voo} · Destino ${bag.destino}${papel === "admin" ? ` · Reserva ${bag.reserva}` : ""} · Status: ${statusDe(bag, t).texto}`;

  $("modal-etapas").innerHTML = ETAPAS.map((e, i) =>
    `<li class="${i < bag.proximo ? "feita" : i === bag.proximo ? "proxima" : ""}">${e.nome}</li>`).join("");

  const p = prazoProxima(bag);
  const m = atrasoMin(bag, t);
  $("modal-prazo").innerHTML = bag.arquivada
    ? `Bagagem arquivada em ${formatarHora(bag.arquivada)}. Fora do monitoramento.`
    : p
    ? `Próxima etapa: <strong>${ETAPAS[bag.proximo].nome}</strong> (local previsto: ${pontoDaLeitura(bag, bag.proximo).local}), prevista até ${hm(p)} (${tempoEsperado(bag, bag.proximo)} min após a última leitura). ${m ? `<span class="atraso-txt">Atrasada ${m} min.</span>` : ""}`
    : "Bagagem entregue na esteira.";

  const caixa = $("modal-alerta");
  if (bag.alerta) {
    caixa.hidden = false;
    caixa.innerHTML = `<strong>${bag.alerta.tipo}</strong><br>${bag.alerta.msg}` +
      (papel === "admin" ? `<br><button class="btn" id="btn-reconhecer">Reconhecer alerta</button>`
                         : `<br><span class="sub">Apenas administradores podem reconhecer alertas.</span>`);
    if (papel === "admin") $("btn-reconhecer").onclick = () => reconhecerAlerta(bag);
  } else {
    caixa.hidden = true;
  }

  $("modal-acoes").innerHTML = papel === "admin"
    ? `<button class="btn" id="btn-arquivar">${bag.arquivada ? "Restaurar bagagem" : "Arquivar bagagem"}</button>` : "";
  if (papel === "admin") $("btn-arquivar").onclick = () => (bag.arquivada ? restaurar(bag) : arquivar(bag));

  $("modal-historico").innerHTML = bag.historico.map(h => `
    <li class="${h.tipo}${h.atraso ? " atraso" : ""}">
      <span class="hora">${formatarHora(h.quando)}${h.leitor ? ` · leitor ${h.leitor}` : ""}</span>
      ${h.etapa ? `<strong>${h.etapa}</strong> · ${h.local}` : `<strong>${h.titulo}</strong>`}
      ${h.tipo !== "ok" || h.atraso ? `<br>${h.etapa ? h.titulo + ": " : ""}${h.msg}` : ""}
    </li>`).join("");

  if (!modal.open) modal.showModal();
}

function reconhecerAlerta(bag) {
  if (papel !== "admin") return;
  bag.alerta = null;
  bag.historico.push({ quando: agora(), tipo: "info", titulo: "Alerta reconhecido pelo administrador", msg: "" });
  atualizar();
}

/* ---------- Minhas malas (usuário comum) ---------- */
function vincularMala() {
  if (papel !== "usuario") return;
  const id = $("mala-id").value.trim().toUpperCase();
  const reserva = $("mala-reserva").value.trim().toUpperCase();
  const bag = bagagens.find(b => b.id === id);
  if (!bag || bag.reserva !== reserva) { // mesma mensagem para os dois erros
    $("mala-erro").textContent = "ID da bagagem ou código da reserva incorretos.";
    return;
  }
  if (!minhasMalas.includes(id)) minhasMalas.push(id);
  salvarMalas();
  $("mala-id").value = "";
  $("mala-reserva").value = "";
  $("mala-erro").textContent = "";
  atualizar();
}

function desvincular(id) {
  if (papel !== "usuario") return;
  minhasMalas = minhasMalas.filter(x => x !== id);
  salvarMalas();
  if (modal.open) modal.close();
  atualizar();
}

/* ---------- Arquivar / restaurar (administrador) ---------- */
function arquivar(bag) {
  if (papel !== "admin") return;
  if (bag.proximo < ETAPAS.length &&
      !confirm(`${bag.id} ainda não chegou à esteira. Arquivar mesmo assim? Ela sairá do monitoramento.`)) return;
  bag.arquivada = agora();
  bag.historico.push({ quando: bag.arquivada, tipo: "info", titulo: "Bagagem arquivada pelo administrador", msg: "" });
  mostrarAviso(`${bag.id} arquivada.`);
  if (modal.open) modal.close();
  atualizar();
}

function restaurar(bag) {
  if (papel !== "admin") return;
  bag.arquivada = null;
  bag.historico.push({ quando: agora(), tipo: "info", titulo: "Bagagem restaurada pelo administrador", msg: "" });
  mostrarAviso(`${bag.id} restaurada para o monitoramento.`);
  if (modal.open) modal.close();
  atualizar();
}

function atualizar() {
  registrarAtrasos(agora());
  renderizar();
  if (modal.open && bagAberta) abrirModal(bagAberta);
}

/* ---------- Áreas de acesso ---------- */
function entrar(p) {
  papel = p;
  document.body.dataset.papel = p;
  try { sessionStorage.setItem("papel", p); } catch (e) {}
  $("selo-papel").textContent = p === "admin" ? "Administrador" : "Usuário comum";
  $("sub-papel").textContent = p === "admin"
    ? "Simule leituras, ajuste os tempos estimados e reconheça alertas"
    : "Acompanhe sua bagagem pelo ID da mala e pelo código da reserva";
  if (login.open) login.close();
  atualizar();
}

function abrirLogin() {
  $("senha").value = "";
  $("login-erro").textContent = "";
  if (!login.open) login.showModal();
}

function sair() {
  papel = null;
  minhasMalas = []; // ao sair, as malas vinculadas são esquecidas
  salvarMalas();
  delete document.body.dataset.papel;
  try { sessionStorage.removeItem("papel"); } catch (e) {}
  if (modal.open) modal.close();
  renderizar(); // limpa os dados da tela
  abrirLogin();
}

function entrarComoAdmin() {
  if ($("senha").value === SENHA_ADMIN) entrar("admin");
  else $("login-erro").textContent = "Senha incorreta.";
}

/* ---------- Tempos estimados (administrador) ---------- */
function criarConfigTempos() {
  $("config-tempos").innerHTML = ETAPAS.map((e, i) => (i === 0 || e.min === null) ? "" :
    `<label>${ETAPAS[i - 1].nome} → ${e.nome}
       <input type="number" min="1" max="600" value="${e.min}" data-i="${i}"></label>`).join("");
}

$("config-tempos").addEventListener("change", e => {
  const campo = e.target.closest("input[data-i]");
  if (papel !== "admin" || !campo) return;
  const v = Math.min(600, Math.max(1, parseInt(campo.value, 10) || 1));
  ETAPAS[campo.dataset.i].min = v;
  campo.value = v;
  atualizar();
});

/* ---------- Eventos ---------- */
function ativarPorClique(lista) {
  lista.addEventListener("click", e => {
    const botao = e.target.closest("[data-acao]");
    if (botao) {
      const acao = botao.dataset.acao;
      if (acao === "desvincular") { desvincular(botao.dataset.id); return; }
      const bag = bagagens.find(b => b.id === botao.dataset.id);
      if (bag) (acao === "arquivar" ? arquivar(bag) : restaurar(bag));
      return;
    }
    const item = e.target.closest("[data-id]");
    if (item) abrirModal(item.dataset.id);
  });
  lista.addEventListener("keydown", e => {
    if (e.target.closest("[data-acao]")) return;
    const item = e.target.closest("[data-id]");
    if (item && e.key === "Enter") abrirModal(item.dataset.id);
  });
}
ativarPorClique($("tabela"));
ativarPorClique($("lista-alertas"));

$("btn-leitura").addEventListener("click", () => simularLeitura(false));
$("btn-erro").addEventListener("click", () => simularLeitura(true));
$("btn-relogio").addEventListener("click", () => {
  if (papel !== "admin") return;
  deslocamentoMs += 15 * 60000;
  mostrarAviso("Relógio do sistema avançado em 15 minutos.");
  atualizar();
});
$("btn-reiniciar").addEventListener("click", () => {
  if (papel !== "admin") return;
  deslocamentoMs = 0;
  bagagens = criarBagagens();
  if (modal.open) modal.close();
  mostrarAviso("Demonstração reiniciada.");
  atualizar();
});

$("busca").addEventListener("input", renderizar);
$("btn-vincular").addEventListener("click", vincularMala);
["mala-id", "mala-reserva"].forEach(id => $(id).addEventListener("keydown", e => { if (e.key === "Enter") vincularMala(); }));
$("aba-ativas").addEventListener("click", () => { visao = "ativas"; renderizar(); });
$("aba-arquivadas").addEventListener("click", () => { visao = "arquivadas"; renderizar(); });
$("filtro-alertas").addEventListener("click", e => {
  const botao = e.target.closest("[data-filtro]");
  if (botao) { filtroAlertas = botao.dataset.filtro; renderizar(); }
});
$("btn-sair").addEventListener("click", sair);
$("login-usuario").addEventListener("click", () => entrar("usuario"));
$("login-admin").addEventListener("click", entrarComoAdmin);
$("senha").addEventListener("keydown", e => { if (e.key === "Enter") entrarComoAdmin(); });
login.addEventListener("cancel", e => e.preventDefault()); // o login não pode ser fechado com Esc

$("modal-fechar").addEventListener("click", () => modal.close());
modal.addEventListener("click", e => { if (e.target === modal) modal.close(); });
modal.addEventListener("close", () => { bagAberta = null; });

/* Início */
criarConfigTempos();
renderizar();
setInterval(() => { $("relogio").textContent = "Horário do sistema: " + formatarHora(agora()); }, 1000);
setInterval(atualizar, 15000);

let salvo = null;
try { salvo = sessionStorage.getItem("papel"); } catch (e) {}
if (salvo === "admin" || salvo === "usuario") entrar(salvo); else abrirLogin();
